# Genesis
### How to use Repo
* Clone the Repo
* Run `pip install -r requirements.txt` 
* Create this folders `self_practice`
    * This folder should hold all your notebooks you practice with
 
### Now let's start cooking 🔥
